﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ContosoUniversity.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniversity.Models;
using System.Web.Mvc;
using ContosoUniversity.DAL;

namespace ContosoUniversity.Controllers.Tests
{
    [TestClass()]
    public class StudentControllerTests
    {
        private readonly int STUDENTCOUNT = 10;
        private StudentController _studentController;
        private SchoolContext db = new SchoolContext();

        [TestInitialize]
        public void SetUp()
        {
            _studentController = new StudentController();
        }

        [TestMethod()]
        public void DetailsTest()
        {
            //var result = _studentController.Index(String.Empty) as ViewResult;
            //var students = result.Model as IQueryable<Student>;
            //Assert.AreEqual(STUDENTCOUNT, students.ToList().Count);

            int id = 1;
            var result = _studentController.Details(id) as ViewResult;
            var returnedStudent = (Student)result.ViewData.Model;
            Assert.AreEqual(id, returnedStudent.StudentID);
        }

        [TestMethod()]
        public void CreateTest()
        {
            Student student = new Student
            {
                FirstMidName = "Integrate",
                LastName = "TEST",
                BirthDate = DateTime.Parse("2010-09-01"),
                Interests = "Test",
                Address = "100 Main St, Salt Lake City, UT 84101",
                Image = StudentController.ImageToArray()
            };

            var result = _studentController.Create(student) as RedirectToRouteResult;
            Assert.AreEqual("Index", result.RouteValues["action"]);
        }

        [TestMethod()]
        public void EditTest()
        {
            int id = 1;
            Student student = db.Students.Find(id);

            var result = _studentController.Edit(id) as ViewResult;
            var returnedStudent = (Student)result.ViewData.Model;
            Assert.AreEqual(1, returnedStudent.StudentID);
        }

        [TestMethod()]
        public void DeleteConfirmedTest()
        {
            var result = _studentController.DeleteConfirmed(12) as RedirectToRouteResult;
            Assert.AreEqual("Index", result.RouteValues["action"]);
        }
    }
}